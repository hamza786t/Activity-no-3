package com.example.listview;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class AddItemActivity extends AppCompatActivity {
    // declare variables and views

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        // initialize views and set up event listeners
    }

    // helper method for adding a new item to the list
}
