package com.example.listview;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class EditItemActivity extends AppCompatActivity {
    // declare variables and views

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_item);

        // initialize views and set up event listeners
    }

    // helper method for updating an existing item in the list
}
