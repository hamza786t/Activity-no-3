package com.example.listview;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class DeleteItemActivity extends AppCompatActivity {
    // declare variables and views

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_item);

        // initialize views and set up event listeners
    }

    // helper method for deleting an item from the list
}
